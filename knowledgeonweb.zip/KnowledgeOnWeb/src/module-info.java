/**
 * 
 */
/**
 * 
 */
module KnowledgeOnWeb {
	requires java.desktop;
}