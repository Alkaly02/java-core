package frames;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class AdmissionFrame implements ActionListener {
	JFrame frame;
	
	JLabel inscriptionPourLabel, programmeNiveauEtudeLabel, ecoleLabel, detailsPersonnel,
	nomLabel, prenomLabel, adresseLabel, citeLabel, etatLabel, codePostalLabel, paysLabel,
	telephoneDomicileLabel,codePaysDomicileLabel, indicatifRegionalDomicileLabel, numeroTelephoneDomicileLabel,
	telephoneBureauLabel, codePaysBureauLabel, indicatifRegionalBureauLabel, numeroTelephoneBureauLabel,
	adresseEmailLabel, sexeLabel, dateNaissanceLabel, moisLabel, jourLabel, anneeLabel;
	
	JTextField programmeNiveauEtudeField, ecoleField, nomField, prenomField, adresseField,
	citeField, etatField, codePostalField, paysField, codePaysDomicileField, indicatifRegionalDomicileField,
	telephoneDomicileField, codePaysBureauField, indicatifRegionalBureauField, telephoneBureauField, adresseEmailField,
	moisField, jourField, anneeField;
	
	ButtonGroup sexeButtonGroup;
	
	JRadioButton femininRadioButton, masculinRadioButton;	
	
	
	public AdmissionFrame() {
		frame = new JFrame("Formlaire d'inscription");
		
		inscriptionPourLabel = new JLabel("Inscription pour");
		
		programmeNiveauEtudeLabel = new JLabel("Programme Niveau d'Etude");
		programmeNiveauEtudeField = new JTextField();
		
		ecoleLabel = new JLabel("Ecole");
		ecoleField = new JTextField();
		
		detailsPersonnel = new JLabel("Details du personnel");
		
		nomLabel = new JLabel("Nom");
		nomField = new JTextField();
		
		prenomLabel = new JLabel("Prenom");
		prenomField = new JTextField();
		
		adresseLabel = new JLabel("Adresse");
		adresseField = new JTextField();
		
		citeLabel = new JLabel("Cite");
		citeField = new JTextField();
		
		etatLabel = new JLabel("Cite");
		etatField = new JTextField();
		
		codePostalLabel = new JLabel("Code postal");
		codePostalField = new JTextField();
		
		paysLabel = new JLabel("Pays");
		paysField = new JTextField();
		
		telephoneDomicileLabel = new JLabel("Telephone(domicile)");
		codePaysDomicileLabel = new JLabel("Code pays");
		codePaysDomicileField = new JTextField();
		indicatifRegionalDomicileLabel = new JLabel("Indicatif regional");
		indicatifRegionalDomicileField = new JTextField();
		numeroTelephoneDomicileLabel = new JLabel("Code pays");
		telephoneDomicileField = new JTextField();
		
		telephoneBureauLabel = new JLabel("Telephone(Bureau)");
		codePaysBureauLabel = new JLabel("Code pays");
		codePaysBureauField = new JTextField();
		indicatifRegionalBureauLabel = new JLabel("Indicatif regional");
		indicatifRegionalBureauField = new JTextField();
		numeroTelephoneBureauLabel = new JLabel("Code pays");
		telephoneBureauField = new JTextField();
		
		adresseEmailLabel = new JLabel("Adresse E-mail :");
		adresseEmailField = new JTextField();
		
		sexeLabel = new JLabel("Pays");
		sexeButtonGroup = new ButtonGroup();
		femininRadioButton = new JRadioButton("Feminin");
		masculinRadioButton = new JRadioButton("Masculin");
		
	    dateNaissanceLabel = new JLabel("Date de naissance");
		moisLabel = new JLabel("Mois");
		moisField = new JTextField();
		jourLabel = new JLabel("Jour");
		jourField = new JTextField();
		anneeLabel = new JLabel("Annee");
		anneeField = new JTextField();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
